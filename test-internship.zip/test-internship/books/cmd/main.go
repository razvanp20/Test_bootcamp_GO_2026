package main

import (
	"books/internal/api"
	"books/internal/persistence"
	"log"
	"os"
)

func main() {
	// cfg := persistence.DBConfig{
	// 	User:     os.Getenv("POSTGRES_USER"),
	// 	Password: os.Getenv("POSTGRES_PASSWORD"),
	// 	DBName:   os.Getenv("POSTGRES_DB"),
	// 	Hostname: os.Getenv("POSTGRES_HOSTNAME"),
	// 	Port:     os.Getenv("POSTGRES_PORT"),
	// }

	_, err := persistence.New(nil)
	if err != nil {
		log.Fatal(err)
	}

	api := api.New()

	api.Run(os.Getenv("HTTP_PORT"))
}
