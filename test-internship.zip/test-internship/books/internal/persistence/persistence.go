package persistence

import (
	"books/internal/models"
	"fmt"
	"log"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

type DBConfig struct {
	User     string
	Password string
	Hostname string
	Port     string
	DBName   string
}

type Persistance struct {
	db *gorm.DB
}

func New(cfg *DBConfig) (*Persistance, error) {
	db, err := connectDB(cfg)
	if err != nil {
		return nil, err
	}

	return &Persistance{db: db}, nil
}

func connectDB(cfg *DBConfig) (*gorm.DB, error) {
	dsn := fmt.Sprintf("postgresql://%s:%s@%s:%s/%s", cfg.User, cfg.Password, cfg.Hostname, cfg.Port, cfg.DBName)

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Info),
	})

	if err != nil {
		return nil, err
	}

	log.Print("Connected to Postgres")

	if err := db.AutoMigrate(&models.Book{}); err != nil {
		return nil, fmt.Errorf("error running automigrate: %s", err)
	}

	return db, nil
}
