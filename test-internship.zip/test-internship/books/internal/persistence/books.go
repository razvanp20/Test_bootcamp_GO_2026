package persistence

import (
	"books/internal/models"
	"context"
)

func (p *Persistance) CreateBook(ctx context.Context, newBook *models.Book) error {
	if err := p.db.WithContext(ctx).Create(newBook).Error; err != nil {
		return err
	}

	return nil
}
