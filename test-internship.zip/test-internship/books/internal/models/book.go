package models

import "time"

type Book struct {
	ID            string    `gorm:"type:uuid;default:gen_random_uuid()"`
	Name          string    `gorm:"type:text"`
	Author        string    `gorm:"type:text"`
	PublishedDate time.Time `gorm:"type:date"`
}
