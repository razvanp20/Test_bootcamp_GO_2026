package apimodels

type CreateBookRequest struct {
	Name          string `json:"name"`
	Author        string `json:"author"`
	PublishedDate string `json:"publishedDate"`
}
