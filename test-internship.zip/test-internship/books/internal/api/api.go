package api

import (
	"github.com/gin-gonic/gin"
)

type API struct{}

func New() *API {
	return &API{}
}

func (a *API) Run(port string) error {
	r := gin.Default()

	r.POST("/books", a.CreateBook)

	err := r.Run(":" + port)
	if err != nil {
		return err
	}

	return nil
}
