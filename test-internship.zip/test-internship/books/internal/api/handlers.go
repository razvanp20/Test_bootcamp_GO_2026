package api

import (
	"books/internal/api/apimodels"

	"github.com/gin-gonic/gin"
)

func (a *API) CreateBook(c *gin.Context) {
	var payload apimodels.CreateBookRequest
	if err := c.ShouldBindJSON(&payload); err != nil {
		c.AbortWithStatusJSON(400, gin.H{"message": "invalid input data"})
		return
	}

	// date, err := time.Parse(time.DateOnly, payload.PublishedDate)
	// if err != nil {
	// 	c.AbortWithStatusJSON(400, gin.H{"message": "invalid input data"})
	// 	return
	// }

	// newBook := models.Book{
	// 	Name:          payload.Name,
	// 	Author:        payload.Author,
	// 	PublishedDate: date,
	// }

	c.Status(201)
}
